<?php $__env->startSection('content'); ?>

<section class="pricing-plan section-bg py-80">
    <div class="container">
        <div class="row gy-4 justify-content-center position-relative">
            <?php $__currentLoopData = $brandPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="pricing-plan-item">
                    <img class="price-shape-bg" src="<?php echo e(asset($activeTemplateTrue.'images/price-shape-bg.png')); ?>" alt="image">
                    <div class="price-shape-2"></div>
                    <div class="pricing-plan-item__top">
                        <h3 class="title" title="<?php echo e(__($item->name)); ?>">
                            <?php if(strlen(__($item->name)) >20): ?>
                            <?php echo e(substr( __($item->name), 0,20).'...'); ?>

                            <?php else: ?>
                            <?php echo e(__($item->name)); ?>

                            <?php endif; ?>
                        </h3>
                        <p class="pricing-plan-item__top-desc"><?php echo app('translator')->get('What You Are Looking For'); ?>!</p>
                    </div>
                    <div class="pricing-plan-item__price">
                        <h3 class="title"><?php echo e($general->cur_sym); ?> <?php echo e(showAmount($item->price)); ?></h3>
                    </div>
                    <div class="pricing-plan-item__list">
                        <ul>
                            <?php if(@$item->content): ?>
                            <?php $__currentLoopData = json_decode(@$item->content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <i class="far fa-check-circle"></i> <?php echo e($value); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="pricing-plan-item__bottom">
                        <a class="btn btn--base" href="<?php echo e(route('user.brnad.package',$item->id)); ?>">
                            <?php echo app('translator')->get('Get Started'); ?> <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php if($sections->secs != null): ?>
<?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/presets/default/brandPackage/brand_package.blade.php ENDPATH**/ ?>