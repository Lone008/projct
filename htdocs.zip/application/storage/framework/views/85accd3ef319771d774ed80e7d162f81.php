
<?php
$method = getContent('payment_method.content',true);
$methodElements = getContent('payment_method.element',false);
?>
<!--========================== Coverage Section Start ==========================-->
<div class="client py-60 section-bg">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-lg-10 position-relative">
                <div class="section-heading  text-center">
                    <span class="subtitle"><?php echo e(__($method->data_values->top_heading)); ?></span>
                    <h2 class="section-heading__title ">
                        <?php echo e(__($method->data_values->heading)); ?>

                    </h2>
                    <p class="section-heading__desc mb-30"><?php echo e(__($method->data_values->sub_heading)); ?></p>
                </div>
            </div>
        </div>
        <div class="client-logos client-slider">
            <?php $__currentLoopData = $methodElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(getImage(getFilePath('paymentMethod').'/'.$item->data_values->method_logo)); ?>" alt="image">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!--========================== Coverage Section End ==========================-->
<?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/presets/default/sections/payment_method.blade.php ENDPATH**/ ?>