<?php
$subscribe = getContent('subscribe.content',true);
?>
<!-- ==================== Subscribe Here ==================== -->
<section class="subscribe-section py-80 bg-img" style="background-image: url(<?php echo e(asset($activeTemplateTrue.'images/subscribe-bg.jpg')); ?>);">
    <div class="container">
        <div class="row  gy-4 justify-content-center align-items-center">
            <div class="col-lg-7">
                <div class="subscribe-wrap position-relative text-center">
                    <div class="section-heading">
                        <span class="subtitle"><?php echo e(__($subscribe->data_values->top_heading)); ?></span>
                        <h2 class="section-heading__title text-white">
                            <?php echo e(__($subscribe->data_values->heading)); ?>

                        </h2>
                        <p class="section-heading__desc"><?php echo e(__($subscribe->data_values->sub_heading)); ?></p>
                    </div>
                    <div class="subscribe-wrap__input">
                        <form action="<?php echo e(route('subscribe')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        <input type="email" class="form--control" name="email" placeholder="<?php echo app('translator')->get('Enter your mail'); ?>">
                        <button><i class="fas fa-paper-plane"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ==================== Subscribe Here ==================== -->
<?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/presets/default/sections/subscribe.blade.php ENDPATH**/ ?>