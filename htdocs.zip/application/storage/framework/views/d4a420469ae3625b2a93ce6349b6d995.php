<?php $__env->startSection('content'); ?>
<div class="col-xl-9 col-lg-12">
    <div class="dashboard-body account-form">
        <div class="dashboard-body__bar">
            <span class="dashboard-body__bar-icon"><i class="las la-bars"></i></span>
        </div>
        <div class="row gy-4 justify-content-center">
            <div class="col-lg-12">
                <div class="order-wrap">
                    <div class="row justify-content-end">
                    </div>
                        <table class="table table--responsive--lg">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Brand Package Name'); ?></th>
                                    <th><?php echo app('translator')->get('Link'); ?></th>
                                    <th><?php echo app('translator')->get('Price'); ?></th>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $__empty_1 = true; $__currentLoopData = $brandPackageOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                               <tr>
                                <td data-label="<?php echo app('translator')->get('Brand Package Name'); ?>"><?php echo e(__($item->name)); ?></td>

                                <?php if($item->link): ?>
                                <td data-label="<?php echo app('translator')->get('Links'); ?>">
                                    <?php $__currentLoopData = json_decode($item->link); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($value); ?>" target="_blank"><?php echo e($value); ?></a>
                                    <br><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <?php endif; ?>

                                <td data-label="<?php echo app('translator')->get('Price'); ?>"><?php echo e($general->cur_sym); ?> <?php echo e(showAmount($item->price)); ?></td>

                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php
                                        echo $item->statusBadge($item->status);
                                    ?>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%" data-label="Package Table"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                               <?php endif; ?>
                            </tbody>
                        </table>
                   </div>
                   <?php if($brandPackageOrder->hasPages()): ?>
                   <div class="py-4">
                       <?php echo e(paginateLinks($brandPackageOrder)); ?>

                   </div>
                   <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/presets/default/user/orders/brand_package_order_index.blade.php ENDPATH**/ ?>