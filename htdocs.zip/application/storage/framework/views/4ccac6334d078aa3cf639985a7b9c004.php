<?php
$service = getContent('service.content',true);
$serviceElements = getContent('service.element',false);
?>
<!-- ==================== Service Start Here ==================== -->
<section class="experience-area py-80 ">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="section-heading  text-center">
                    <span class="subtitle"><?php echo e(__($service->data_values->top_heading)); ?></span>
                    <h2 class="section-heading__title">
                        <?php echo e(__($service->data_values->heading)); ?>

                    </h2>
                    <p class="section-heading__desc"><?php echo e(__($service->data_values->sub_heading)); ?></p>
                </div>
            </div>
        </div>
        <div class="row gy-4 justify-content-center">
            <?php $__currentLoopData = $serviceElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4">
                <div class="experience">
                    <div class="experience__icon">
                        <?php echo $item->data_values->service_icon; ?>
                    </div>
                    <div class="experience__content">
                        <h3 class="title">
                            <?php if(strlen(__($item->data_values->title)) >50): ?>
                            <?php echo e(substr( __($item->data_values->title), 0,50).'...'); ?>

                            <?php else: ?>
                            <?php echo e(__($item->data_values->title)); ?>

                            <?php endif; ?>
                        </h3>
                    </div>
                    <div class="experience__content">
                        <p>
                            <?php if(strlen(strip_tags($item->data_values->description)) >140): ?>
                            <?php echo e(substr(strip_tags($item->data_values->description), 0,140).'...'); ?>

                            <?php else: ?>
                            <?php echo e(strip_tags($item->data_values->description)); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<!-- ==================== Service End Here ==================== -->
<?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/presets/default/sections/service.blade.php ENDPATH**/ ?>