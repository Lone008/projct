<?php $__env->startSection('content'); ?>
<section class="account bg-img login py-80 position-relative">
    <div class="account-inner">
        <div class="container">
            <div class="row gy-4 justify-content-center">
                <div class="col-lg-6">
                    <div class="account-form">
                        <div class="account-form__content mb-4">
                            <h3 class="account-form__title mb-2"> <?php echo e(__($pageTitle)); ?> </h3>
                        </div>
                        <form method="POST" action="<?php echo e(route('user.data.submit')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row gy-3">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="firstname" class="form--label"> <?php echo app('translator')->get('First Name'); ?></label>
                                        <input type="text" class="form--control" id="firstname" name="firstname"
                                        value="<?php echo e(old('firstname')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="lastname" class="form--label"> <?php echo app('translator')->get('Last Name'); ?></label>
                                        <input type="text" class="form--control" id="lastname" name="lastname"
                                        value="<?php echo e(old('lastname')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="address" class="form--label"> <?php echo app('translator')->get('Address'); ?></label>
                                        <input type="text" class="form--control" id="address" name="address"
                                        value="<?php echo e(old('address')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="state" class="form--label"> <?php echo app('translator')->get('State'); ?></label>
                                        <input type="text" class="form--control" id="state" name="state"
                                        value="<?php echo e(old('state')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="zip" class="form--label"> <?php echo app('translator')->get('Zip'); ?></label>
                                        <input type="text" class="form--control" id="zip" name="zip"
                                        value="<?php echo e(old('zip')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="city" class="form--label"> <?php echo app('translator')->get('City'); ?></label>
                                        <input type="text" class="form--control" id="city" name="city"
                                        value="<?php echo e(old('city')); ?>" required>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <button type="submit" class="btn btn--base w-50">
                                        <?php echo app('translator')->get('Submit'); ?> <i class="fa-sharp fas fa-arrow-right"></i>
                                        <span style="top: 40.6094px; left: 80px;"></span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
     </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/presets/default/user/user_data.blade.php ENDPATH**/ ?>