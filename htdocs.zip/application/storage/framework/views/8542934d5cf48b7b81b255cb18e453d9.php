<?php $__env->startSection('content'); ?>
<?php
    $user = auth()->user();
?>
<div class="col-xl-9 col-lg-12">
    <div class="dashboard-body">
        <div class="dashboard-body__bar">
            <span class="dashboard-body__bar-icon"><i class="las la-bars"></i></span>
        </div>
        <div class="row gy-4 justify-content-center">
            <div class="col-xl-4 col-lg-4 col-sm-4">
                <div class="dashboard-card">
                    <span class="banner-effect-1"></span>
                    <div class="dashboard-card__icon">
                        <i class="las la-hand-holding-usd"></i>
                    </div>
                    <div class="dashboard-card__content">
                        <h5 class="dashboard-card__title"><?php echo app('translator')->get('Balance'); ?></h5>
                        <h4 class="dashboard-card__amount"><?php echo e($general->cur_sym); ?> <?php echo e(showAmount($user->balance)); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-4">
                <a class="d-block" href="<?php echo e(route('user.order.index')); ?>">
                <div class="dashboard-card">
                    <span class="banner-effect-1"></span>
                    <div class="dashboard-card__icon">
                        <i class="fas fa-cart-plus"></i>
                    </div>
                    <div class="dashboard-card__content">
                        <h5 class="dashboard-card__title"><?php echo app('translator')->get('Orders'); ?> </h5>
                        <h4 class="dashboard-card__amount"><?php echo e(__($orderCount)); ?></h4>
                    </div>
                </div>
                </a>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-4">
                <a class="d-block" href="<?php echo e(route('user.brnad.package.index')); ?>">
                <div class="dashboard-card">
                    <span class="banner-effect-1"></span>
                    <div class="dashboard-card__icon">
                        <i class="fas fa-cart-plus"></i>
                    </div>
                    <div class="dashboard-card__content">
                        <h5 class="dashboard-card__title"><?php echo app('translator')->get('Brand Package Orders'); ?> </h5>
                        <h4 class="dashboard-card__amount"><?php echo e(__($brandOrderCount)); ?></h4>
                    </div>
                </div>
                </a>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-4">
                <a class="d-block" href="<?php echo e(route('user.transactions')); ?>">
                    <div class="dashboard-card">
                        <span class="banner-effect-1"></span>
                        <div class="dashboard-card__icon">
                            <i class="fas fa-funnel-dollar"></i>
                        </div>
                        <div class="dashboard-card__content">
                            <h5 class="dashboard-card__title"><?php echo app('translator')->get('Transactions'); ?></h5>
                            <h4 class="dashboard-card__amount"><?php echo e($transectionCount); ?></h4>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-xl-4 col-lg-4 col-sm-4">
                <a class="d-block" href="<?php echo e(route('user.deposit.history')); ?>">
                    <div class="dashboard-card">
                        <span class="banner-effect-1"></span>
                        <div class="dashboard-card__icon">
                            <i class="fas fa-clipboard-check"></i>
                        </div>
                        <div class="dashboard-card__content">
                            <h5 class="dashboard-card__title"><?php echo app('translator')->get('Deposit Log'); ?></h5>
                            <h4 class="dashboard-card__amount"><?php echo e($depositCount); ?></h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-4">
                <a class="d-block" href="<?php echo e(route('ticket')); ?>">
                    <div class="dashboard-card">
                        <span class="banner-effect-1"></span>
                        <div class="dashboard-card__icon">
                            <i class="fas fa-clipboard-check"></i>
                        </div>
                        <div class="dashboard-card__content">
                            <h5 class="dashboard-card__title"><?php echo app('translator')->get('Tickets'); ?></h5>
                            <h4 class="dashboard-card__amount"><?php echo e($ticketCount); ?></h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/presets/default/user/dashboard.blade.php ENDPATH**/ ?>