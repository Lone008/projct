<?php $__env->startSection('content'); ?>
  <!--=======-** Login start **-=======-->
<section class="account bg-img login py-80 position-relative">
    <div class="account-inner">
        <div class="container">
            <div class="row gy-4 justify-content-center">
                <div class="col-lg-6">
                    <div class="account-form">
                        <div class="account-form__content mb-4">
                            <h3 class="account-form__title mb-2"> <?php echo app('translator')->get('Sign In Your Account'); ?> </h3>
                            <p class="account-form__desc"><?php echo app('translator')->get('Please input your username and password and login to your account to get access to your dashboard'); ?>.</p>
                        </div>
                        <form method="POST" action="<?php echo e(route('user.login')); ?>" class="verify-gcaptcha">
                            <?php echo csrf_field(); ?>
                            <div class="row gy-3">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="username" class="form--label"> <?php echo app('translator')->get('Username or Email'); ?></label>
                                        <input type="text" class="form--control" id="username" name="username" value="<?php echo e(old('username')); ?>" required>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <label for="your-password" class="form--label"><?php echo app('translator')->get('Password'); ?></label>
                                    <div class="input-group">
                                        <input id="your-password" type="password" name="password" class="form-control form--control" required>
                                        <div class="password-show-hide fas fa-lock " id="#your-password"></div>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginalff0a9fdc5428085522b49c68070c11d6 = $component; } ?>
<?php $component = App\View\Components\Captcha::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('captcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Captcha::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff0a9fdc5428085522b49c68070c11d6)): ?>
<?php $component = $__componentOriginalff0a9fdc5428085522b49c68070c11d6; ?>
<?php unset($__componentOriginalff0a9fdc5428085522b49c68070c11d6); ?>
<?php endif; ?>
                                </div>
                                <div class="col-sm-12">
                                    <div class="d-flex flex-wrap justify-content-between">
                                        <div class="form--check">
                                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                            <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="remember"><?php echo app('translator')->get('Remember me'); ?></label>
                                        </div>
                                        <a href="<?php echo e(route('user.password.request')); ?>" class="forgot-password text--base"><?php echo app('translator')->get('Forgot Your Password'); ?>?</a>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <button type="submit" class="btn btn--base w-100" id="recaptcha">
                                        <?php echo app('translator')->get('Sign In'); ?> <i class="fa-sharp fas fa-arrow-right"></i>
                                        <span style="top: 40.6094px; left: 80px;"></span>
                                    </button>
                                </div>
                                <div class="col-sm-12">
                                    <div class="have-account text-center">
                                        <p class="have-account__text"><?php echo app('translator')->get('Don\'t have any account?'); ?> <a href="<?php echo e(route('user.register')); ?>" class="have-account__link text--base"><?php echo app('translator')->get('Create Account'); ?></a></p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
     </div>
</section>
<!--=======-** Login End **-=======-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smm\application\resources\views/presets/default/user/auth/login.blade.php ENDPATH**/ ?>