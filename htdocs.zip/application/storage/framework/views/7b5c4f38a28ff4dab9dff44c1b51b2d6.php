<?php echo  loadExtension('tawk-chat') ?>
<?php echo  loadExtension('google-analytics') ?>
<?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/includes/plugins.blade.php ENDPATH**/ ?>