<?php $__env->startSection('content'); ?>
<div class="col-xl-9 col-lg-12">
    <div class="dashboard-body account-form">
        <div class="dashboard-body__bar">
            <span class="dashboard-body__bar-icon"><i class="las la-bars"></i></span>
        </div>
        <div class="row gy-4 justify-content-center">
            <div class="col-lg-12">
                <h4><?php echo e(__($pageTitle)); ?></h4>
                <div class="order-wrap">
                    <div class="row justify-content-end">
                    </div>
                        <table class="table table--responsive--lg">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Order No'); ?></th>
                                    <th><?php echo app('translator')->get('Category Name'); ?></th>
                                    <th><?php echo app('translator')->get('Service Name'); ?></th>
                                    <th><?php echo app('translator')->get('Link'); ?></th>
                                    <th><?php echo app('translator')->get('Price'); ?></th>
                                    <th><?php echo app('translator')->get('Start Counter'); ?></th>
                                    <th><?php echo app('translator')->get('Remain Counter'); ?></th>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                               <tr class="text-center">
                                <td data-label="<?php echo app('translator')->get('Order No'); ?>">#<?php echo e(__($item->order_no)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Category Name'); ?>"><?php echo e(__(@$item->category->name)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Service Name'); ?>"><?php echo e(__(@$item->service->name)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Link'); ?>">
                                    <a href="<?php echo e(__($item->link)); ?>" target="_blank"><?php echo e(__($item->link)); ?></a>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Price'); ?>"><?php echo e($general->cur_sym); ?> <?php echo e(showAmount($item->price)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Start Counter'); ?>"><?php echo e(__($item->start_count)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Remain Counter'); ?>"><?php echo e(__($item->remain_count)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php
                                        echo $item->statusBadge($item->status);
                                    ?>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%" data-label="Order Table"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                   </div>
                   <?php if($orders->hasPages()): ?>
                   <div class="py-4">
                       <?php echo e(paginateLinks($orders)); ?>

                   </div>
                   <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP8.1\htdocs\application\resources\views/presets/default/user/orders/index.blade.php ENDPATH**/ ?>