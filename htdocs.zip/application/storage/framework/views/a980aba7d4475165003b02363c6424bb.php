<!-- ==================== Breadcumb Start Here ==================== -->
<section class="breadcumb ">
    <span class="banner-effect-1"></span>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcumb__wrapper">
                    <h2 class="breadcumb__title"><?php echo e(__($pageTitle)); ?> </h2>
                    <ul class="breadcumb__list">
                        <li class="breadcumb__item"><a href="<?php echo e(route('home')); ?>" class="breadcumb__link"> <i class="las la-home"></i> <?php echo app('translator')->get('Home'); ?></a> </li>
                        <li class="breadcumb__item"><i class="fas fa-arrow-right"></i></li>
                        <li class="breadcumb__item"> <span class="breadcumb__item-text"> <?php echo e(__($pageTitle)); ?></span> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ==================== Breadcumb End Here ==================== -->
<?php /**PATH C:\xampp\htdocs\smm\application\resources\views/presets/default/components/breadcrumb.blade.php ENDPATH**/ ?>